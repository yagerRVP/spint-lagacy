
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.static('.'));
app.use(express.json());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'form.html'));
});

app.post('/gpt', async (req, res) => {
  const messages = req.body.messages;
  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).send({ error: "OpenAI API key not configured" });
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      signal: controller.signal,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: messages
      })
    });

    const data = await response.json();
    res.send(data);
  } catch (err) {
    console.error("GPT Error:", err);
    res.status(500).send({ error: "Failed to contact GPT" });
  }
});

app.listen(5000, '0.0.0.0', () => console.log('Server running on port 5000'));
