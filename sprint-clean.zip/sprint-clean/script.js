
const chatBox = document.getElementById('chat-box');
const input = document.getElementById('user-input');

let messages = [
  {
    role: "system",
    content: "You are a motivating CAMP business coach specializing in legacy planning and financial independence. Your approach is empathetic yet direct, focusing on actionable steps and measurable goals. Draw from proven business principles and real-world experience to guide users toward financial success. Be clear, bold, and positive while maintaining professionalism."
  }
];

// Add initial welcome message
window.onload = () => {
    addMessage('Welcome to CAMP! How can I help you today?');
};

function addMessage(message, isUser = false) {
    const div = document.createElement('div');
    div.style.padding = '12px';
    div.style.margin = '8px';
    div.style.backgroundColor = isUser ? '#1a1a1a' : '#2a2a2a';
    div.style.borderRadius = '8px';
    div.style.color = '#fff';
    div.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
    div.style.maxWidth = '80%';
    div.style.marginLeft = isUser ? 'auto' : '10px';
    div.style.marginRight = isUser ? '10px' : 'auto';
    div.innerHTML = `<strong>${isUser ? 'You' : 'Coach'}:</strong> ${message}`;
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
}

async function handleInput() {
    const value = input.value.trim();
    if (!value) return;

    addMessage(value, true);
    input.value = '';
    
    // Show loading indicator
    const loadingDiv = document.createElement('div');
    loadingDiv.textContent = 'Coach is typing...';
    loadingDiv.style.padding = '8px';
    loadingDiv.style.fontStyle = 'italic';
    loadingDiv.style.color = '#666';
    chatBox.appendChild(loadingDiv);
    
    messages.push({ role: "user", content: value });

    try {
        const response = await fetch('/gpt', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ messages })
        });

        const data = await response.json();
        
        if (data.error) {
            addMessage("Error: " + data.error);
            return;
        }

        if (data.choices && data.choices[0] && data.choices[0].message) {
            const reply = data.choices[0].message.content;
            messages.push({ role: "assistant", content: reply });
            chatBox.removeChild(chatBox.lastChild); // Remove loading indicator
            addMessage(reply);
        }
    } catch (error) {
        console.error('Error:', error);
        addMessage('Failed to get response. Please try again.');
    }
}

// Handle Enter key
input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        handleInput();
    }
});
